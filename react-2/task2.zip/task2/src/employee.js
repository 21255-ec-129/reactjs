import React, { useState } from 'react';

const EmployeeTable = () => {
  const [employees, setEmployees] = useState([
    { fname: 'J', lname: 'meena', email: 'meena@example.com', salary: 50000, date: '2023-10-16' },
    { fname: 'A', lname: 'ammu', email: 'ammu@example.com', salary: 60000, date: '2023-10-17' },
    { fname: 'K', lname: 'jyothi', email: 'jyothi@example.com', salary: 55000, date: '2023-10-18' },
  ]);

  const [newEmployee, setNewEmployee] = useState({ fname: '', lname: '', email: '', salary: 0, date: '' });
  const [editingIndex, setEditingIndex] = useState(-1);

  const handleAddEmployee = () => {
    setEmployees([...employees, newEmployee]);
    setNewEmployee({ fname: '', lname: '', email: '', salary: 0, date: '' });
  };

  const handleEditEmployee = (index) => {
    setEditingIndex(index);
    setNewEmployee(employees[index]);
  };

  const handleUpdateEmployee = () => {
    const updatedEmployees = [...employees];
    updatedEmployees[editingIndex] = newEmployee;
    setEmployees(updatedEmployees);
    setEditingIndex(-1);
    setNewEmployee({ fname: '', lname: '', email: '', salary: 0, date: '' });
  };

  const handleDeleteEmployee = (index) => {
    const updatedEmployees = employees.filter((_, i) => i !== index);
    setEmployees(updatedEmployees);
  };

  return (
    <div>
      <h2>Employee Management Software</h2>
      <div>
        <input
          type="text"
          placeholder="First Name"
          value={newEmployee.fname}
          onChange={(e) => setNewEmployee({ ...newEmployee, fname: e.target.value })}
        />
        <input
          type="text"
          placeholder="Last Name"
          value={newEmployee.lname}
          onChange={(e) => setNewEmployee({ ...newEmployee, lname: e.target.value })}
        />
        <input
          type="text"
          placeholder="Email"
          value={newEmployee.email}
          onChange={(e) => setNewEmployee({ ...newEmployee, email: e.target.value })}
        />
        <input
          type="number"
          placeholder="Salary"
          value={newEmployee.salary}
          onChange={(e) => setNewEmployee({ ...newEmployee, salary: parseInt(e.target.value) })}
        />
        <input
          type="date"
          placeholder="Date"
          value={newEmployee.date}
          onChange={(e) => setNewEmployee({ ...newEmployee, date: e.target.value })}
        />
        <button onClick={handleAddEmployee}>Add Employee</button>
        <button>Logout</button>
      </div>
      <br />
      <center>
        <table border={1}>
          <thead>
            <tr>
              <th>S.No</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Salary</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((employee, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>
                  {index === editingIndex ? (
                    <input
                      type="text"
                      value={newEmployee.fname}
                      onChange={(e) => setNewEmployee({ ...newEmployee, fname: e.target.value })}
                    />
                  ) : (
                    employee.fname
                  )}
                </td>
                <td>
                  {index === editingIndex ? (
                    <input
                      type="text"
                      value={newEmployee.lname}
                      onChange={(e) => setNewEmployee({ ...newEmployee, lname: e.target.value })}
                    />
                  ) : (
                    employee.lname
                  )}
                </td>
                <td>
                  {index === editingIndex ? (
                    <input
                      type="text"
                      value={newEmployee.email}
                      onChange={(e) => setNewEmployee({ ...newEmployee, email: e.target.value })}
                    />
                  ) : (
                    employee.email
                  )}
                </td>
                <td>
                  {index === editingIndex ? (
                    <input
                      type="number"
                      value={newEmployee.salary}
                      onChange={(e) => setNewEmployee({ ...newEmployee, salary: parseInt(e.target.value) })}
                    />
                  ) : (
                    employee.salary
                  )}
                </td>
                <td>
                  {index === editingIndex ? (
                    <input
                      type="date"
                      value={newEmployee.date}
                      onChange={(e) => setNewEmployee({ ...newEmployee, date: e.target.value })}
                    />
                  ) : (
                    employee.date
                  )}
                </td>
                <td>
                  {index === editingIndex ? (
                    <button onClick={handleUpdateEmployee}>Update</button>
                  ) : (
                    <button onClick={() => handleEditEmployee(index)}>Edit</button>
                  )}
                  <button onClick={() => handleDeleteEmployee(index)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </center>
    </div>
  );
};

export default EmployeeTable;
