import EmployeeTable from './employee';
import './App.css';

function App() {
  return (
    <div className="App">
      <EmployeeTable />
    </div>
  );
}

export default App;
